import { MessageSquare, Building2, Users, UserCog, X, Settings, Store } from 'lucide-react';
import { cn } from './ui/utils';
import alcLogo from 'figma:asset/b32430fc1c0b44292275f805dd83220ee644a8bb.png';

interface NavItem {
  icon: React.ElementType;
  label: string;
  id: string;
}

interface SidebarProps {
  activePage: string;
  onNavigate: (page: string) => void;
  isOpen?: boolean;
  onClose?: () => void;
}

export function Sidebar({ activePage, onNavigate, isOpen = false, onClose }: SidebarProps) {
  const mainNavItems: NavItem[] = [
    { icon: MessageSquare, label: 'Messaging', id: 'messaging' },
    { icon: Building2, label: 'Residents', id: 'residents' },
    { icon: UserCog, label: 'Staff', id: 'staff' },
    { icon: Store, label: 'Vendors', id: 'vendors' },
    { icon: Users, label: 'Users', id: 'users' },
  ];

  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <aside className={cn(
        "fixed lg:static inset-y-0 left-0 z-50 w-64 border-r bg-white transition-transform duration-300 ease-in-out lg:translate-x-0 flex flex-col",
        isOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        {/* Logo Area */}
        {/* TODO: Replace with facility logo from API/mock data (facility.logo) */}
        {/* This default ALC logo should be replaced with dynamic facility branding */}
        <div className="p-6 border-b flex items-center justify-center relative">
          <img src={alcLogo} alt="Facility Logo" className="h-12 w-auto" />
          {/* Close button for mobile */}
          <button
            onClick={onClose}
            className="lg:hidden absolute top-6 right-6 p-2 hover:bg-[#f9fafb] rounded-lg transition-colors"
          >
            <X className="h-5 w-5 text-[#64748b]" />
          </button>
        </div>
        
        <nav className="flex-1 p-4 overflow-y-auto">
          <ul className="space-y-1">
            {mainNavItems.map((item) => {
              const Icon = item.icon;
              const isActive = activePage === item.id;
              return (
                <li key={item.label}>
                  <button
                    onClick={() => onNavigate(item.id)}
                    className={cn(
                      "w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 text-left",
                      isActive
                        ? "bg-[#eff6ff] text-[#2563eb]"
                        : "text-[#64748b] hover:bg-[#f9fafb] hover:text-[#2563eb]"
                    )}
                  >
                    <Icon className="h-5 w-5" />
                    <span className="text-sm font-medium">{item.label}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>

        {/* Settings at bottom */}
        <div className="p-4 border-t">
          <button
            onClick={() => onNavigate('settings')}
            className={cn(
              "w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 text-left",
              activePage === 'settings'
                ? "bg-[#eff6ff] text-[#2563eb]"
                : "text-[#64748b] hover:bg-[#f9fafb] hover:text-[#2563eb]"
            )}
          >
            <Settings className="h-5 w-5" />
            <span className="text-sm font-medium">Settings</span>
          </button>
        </div>
      </aside>
    </>
  );
}