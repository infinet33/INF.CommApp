import { MessageSquare, Calendar, FileText, Heart, Home, X, Building2 } from 'lucide-react';
import { cn } from './ui/utils';
import alcLogo from 'figma:asset/b32430fc1c0b44292275f805dd83220ee644a8bb.png';

interface NavItem {
  icon: React.ElementType;
  label: string;
  id: string;
}

interface NormalUserSidebarProps {
  activePage: string;
  onNavigate: (page: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

export function NormalUserSidebar({ activePage, onNavigate, isOpen, onClose }: NormalUserSidebarProps) {
  const navItems: NavItem[] = [
    { icon: MessageSquare, label: 'Messages', id: 'messages' },
    { icon: Calendar, label: 'Calendar', id: 'calendar' },
    { icon: FileText, label: 'Documents', id: 'documents' },
    { icon: Heart, label: 'Health', id: 'health' },
    { icon: Home, label: 'Home', id: 'home' },
    { icon: Building2, label: 'Facility', id: 'facility' },
  ];

  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed lg:static inset-y-0 left-0 z-50 w-64 bg-white border-r border-[#e2e8f0] transition-transform duration-300 ease-in-out lg:translate-x-0 flex flex-col",
          isOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        {/* Logo Area */}
        {/* TODO: Replace with facility logo from API/mock data (facility.logo) */}
        {/* This default ALC logo should be replaced with dynamic facility branding */}
        <div className="p-6 border-b flex items-center justify-center relative">
          <img src={alcLogo} alt="Facility Logo" className="h-12 w-auto" />
          <button
            onClick={onClose}
            className="lg:hidden absolute top-6 right-6 p-2 hover:bg-[#f9fafb] rounded-lg transition-colors"
          >
            <X className="h-5 w-5 text-[#64748b]" />
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4 overflow-y-auto">
          <ul className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activePage === item.id;
              return (
                <li key={item.id}>
                  <button
                    onClick={() => onNavigate(item.id)}
                    className={cn(
                      "w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 text-left",
                      isActive
                        ? "bg-[#eff6ff] text-[#2563eb]"
                        : "text-[#64748b] hover:bg-[#f9fafb] hover:text-[#2563eb]"
                    )}
                  >
                    <Icon className="h-5 w-5" />
                    <span className="text-sm font-medium">{item.label}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>

        {/* Footer */}
        <div className="p-4 border-t border-[#e2e8f0]">
          <div className="text-center">
            <p className="text-xs text-[#64748b]">Need help?</p>
            <p className="text-xs text-[#2563eb] cursor-pointer hover:underline font-medium">Contact Support</p>
          </div>
        </div>
      </aside>
    </>
  );
}