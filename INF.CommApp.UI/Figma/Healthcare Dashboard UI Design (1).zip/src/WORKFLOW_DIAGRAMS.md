# Valencia Assisted Living - Screen Workflows & User Journeys

---

## Overview

This document provides visual workflow diagrams and user journey maps for all major features in the Valencia Assisted Living Dashboard.

---

## 1. Residents Management Workflow

```
┌─────────────────────────────────────────────────────────────────┐
│                      RESIDENTS PAGE                             │
│  Components: ResidentsPage.tsx, ResidentCard.tsx,              │
│              ResidentDetailsModal.tsx, AddResidentModal.tsx     │
└─────────────────────────────────────────────────────────────────┘

User Journey: View Residents
┌─────────┐      ┌──────────────┐      ┌─────────────────┐
│ Landing │─────>│ Grid Display │─────>│ See 12 Cards    │
│  Page   │      │   Loads      │      │ with Pagination │
└─────────┘      └──────────────┘      └─────────────────┘
                        │
                        ├─> API Call: GET /api/residents?page=1&pageSize=12
                        │
                        └─> State Update: residents array populated

User Journey: Search Residents
┌──────────┐      ┌────────────┐      ┌─────────────┐      ┌─────────┐
│ Type in  │─────>│ Debounce   │─────>│ API Call    │─────>│ Update  │
│ Search   │      │ 300ms      │      │ with search │      │  Grid   │
└──────────┘      └────────────┘      └─────────────┘      └─────────┘
                                            │
                                            └─> GET /api/residents?search=Margaret

User Journey: Filter by Care Level
┌──────────┐      ┌─────────────┐      ┌─────────┐
│ Select   │─────>│ API Call    │─────>│ Update  │
│ Filter   │      │ with filter │      │  Grid   │
└──────────┘      └─────────────┘      └─────────┘
                        │
                        └─> GET /api/residents?careLevel=Assisted

User Journey: View Resident Details
┌───────────┐      ┌─────────────┐      ┌──────────────┐
│ Click     │─────>│ Open Modal  │─────>│ Show Full    │
│ Card      │      │ with Data   │      │ Profile      │
└───────────┘      └─────────────┘      └──────────────┘
                          │
                          └─> Data already in memory (no API call needed)

User Journey: Add New Resident
┌───────────┐   ┌──────────┐   ┌──────────┐   ┌─────────┐   ┌─────────┐
│ Click Add │──>│ Open     │──>│ Fill     │──>│ Submit  │──>│ Success │
│ Button    │   │ Modal    │   │ Form     │   │ Form    │   │ Toast   │
└───────────┘   └──────────┘   └──────────┘   └─────────┘   └─────────┘
                                                     │
                                                     ├─> POST /api/residents
                                                     ├─> Get new resident data
                                                     └─> Add to grid optimistically

User Journey: Edit Resident
┌───────────┐   ┌──────────┐   ┌──────────┐   ┌─────────┐   ┌─────────┐
│ Click     │──>│ Open     │──>│ Update   │──>│ Submit  │──>│ Success │
│ Edit      │   │ Modal    │   │ Fields   │   │ Changes │   │ Toast   │
└───────────┘   └──────────┘   └──────────┘   └─────────┘   └─────────┘
                     │                               │
                     │                               ├─> PUT /api/residents/:id
                     └─> Pre-filled with data        ├─> Get updated data
                                                     └─> Update grid

User Journey: Delete Resident
┌───────────┐   ┌──────────┐   ┌─────────┐   ┌─────────┐
│ Click     │──>│ Confirm  │──>│ Delete  │──>│ Remove  │
│ Delete    │   │ Dialog   │   │ Action  │   │ from    │
└───────────┘   └──────────┘   └─────────┘   │ Grid    │
                                     │        └─────────┘
                                     └─> DELETE /api/residents/:id
```

---

## 2. Staff Management Workflow

```
┌─────────────────────────────────────────────────────────────────┐
│                        STAFF PAGE                               │
│  Component: StaffPage.tsx                                       │
└─────────────────────────────────────────────────────────────────┘

User Journey: View Staff
┌─────────┐      ┌──────────────┐      ┌─────────────────┐
│ Landing │─────>│ Table        │─────>│ See All Staff   │
│  Page   │      │ Display      │      │ Members         │
└─────────┘      └──────────────┘      └─────────────────┘
                        │
                        └─> API Call: GET /api/staff

Table Structure:
┌────────────┬──────────┬────────────┬─────────────┬────────┬─────────┐
│ Name       │ Role     │ Department │ Contact     │ Status │ Actions │
├────────────┼──────────┼────────────┼─────────────┼────────┼─────────┤
│ Jennifer   │ Care     │ Care       │ email       │ Active │ ⋮       │
│ Lee        │ Coord.   │ Services   │ phone       │        │         │
├────────────┼──────────┼────────────┼─────────────┼────────┼─────────┤
│ David      │ Activities│ Recreation│ email       │ Active │ ⋮       │
│ Martinez   │ Director │            │ phone       │        │         │
└────────────┴──────────┴────────────┴─────────────┴────────┴─────────┘

User Journey: Add Staff
┌───────────┐   ┌──────────┐   ┌──────────────┐   ┌─────────┐
│ Click Add │──>│ Open     │──>│ Fill Form    │──>│ Submit  │
│ Staff     │   │ Dialog   │   │ - Name       │   │         │
└───────────┘   └──────────┘   │ - Email      │   └─────────┘
                                │ - Phone      │        │
                                │ - Role       │        │
                                │ - Department │        │
                                │ - Shift      │        │
                                │ - Status     │        │
                                └──────────────┘        │
                                                        └─> POST /api/staff

User Journey: Edit Staff
┌───────────┐   ┌──────────┐   ┌──────────┐   ┌─────────┐
│ Click ⋮   │──>│ Click    │──>│ Update   │──>│ Save    │
│ Menu      │   │ Edit     │   │ Fields   │   │ Changes │
└───────────┘   └──────────┘   └──────────┘   └─────────┘
                                                     │
                                                     └─> PUT /api/staff/:id

User Journey: Search & Filter
┌──────────┐      ┌────────────┐      ┌─────────────┐
│ Search   │─────>│ API Call   │─────>│ Update      │
│ by Name  │      │            │      │ Table       │
└──────────┘      └────────────┘      └─────────────┘
                        │
                        └─> GET /api/staff?search=Jennifer

┌──────────┐      ┌────────────┐      ┌─────────────┐
│ Filter   │─────>│ API Call   │─────>│ Update      │
│ by Role  │      │            │      │ Table       │
└──────────┘      └────────────┘      └─────────────┘
                        │
                        └─> GET /api/staff?role=Nurse
```

---

## 3. Vendors Management Workflow

```
┌─────────────────────────────────────────────────────────────────┐
│                      VENDORS PAGE                               │
│  Component: VendorsPage.tsx                                     │
└─────────────────────────────────────────────────────────────────┘

User Journey: View Vendors
┌─────────┐      ┌──────────────┐      ┌─────────────────┐
│ Landing │─────>│ Table        │─────>│ See All Vendors │
│  Page   │      │ Display      │      │                 │
└─────────┘      └──────────────┘      └─────────────────┘
                        │
                        └─> API Call: GET /api/vendors

Table Structure:
┌──────────────┬──────────┬───────────┬───────────┬────────┬─────────┐
│ Vendor Name  │ Type     │ Contact   │ Phone     │ Status │ Actions │
├──────────────┼──────────┼───────────┼───────────┼────────┼─────────┤
│ Caring Hands │ Home     │ Emily     │ (555)     │ Active │ ⋮       │
│ Home Health  │ Health   │ Rodriguez │ 345-6789  │        │         │
├──────────────┼──────────┼───────────┼───────────┼────────┼─────────┤
│ Mobility     │ Medical  │ James     │ (555)     │ Active │ ⋮       │
│ Plus         │ Equipment│ Wilson    │ 456-7890  │        │         │
└──────────────┴──────────┴───────────┴───────────┴────────┴─────────┘

Vendor Types Available:
┌─────────────────────────────────────────────┐
│ • Home Health Agency                        │
│ • Hospice                                   │
│ • Pharmacy                                  │
│ • Medical Equipment                         │
│ • Therapy Services                          │
│ • Transportation                            │
│ • Lab Services                              │
│ • Other                                     │
└─────────────────────────────────────────────┘

User Journey: Add Vendor
┌───────────┐   ┌──────────┐   ┌──────────────┐   ┌─────────┐
│ Click Add │──>│ Open     │──>│ Fill Form    │──>│ Submit  │
│ Vendor    │   │ Dialog   │   │ - Name       │   │         │
└───────────┘   └──────────┘   │ - Type       │   └─────────┘
                                │ - Contact    │        │
                                │ - Email      │        │
                                │ - Phone      │        │
                                │ - Address    │        │
                                │ - Status     │        │
                                │ - Notes      │        │
                                └──────────────┘        │
                                                        └─> POST /api/vendors

User Journey: Filter by Type
┌──────────────┐   ┌────────────┐   ┌─────────────┐
│ Select       │──>│ API Call   │──>│ Update      │
│ Vendor Type  │   │            │   │ Table       │
└──────────────┘   └────────────┘   └─────────────┘
                          │
                          └─> GET /api/vendors?type=Home Health Agency
```

---

## 4. Users Management Workflow

```
┌─────────────────────────────────────────────────────────────────┐
│                        USERS PAGE                               │
│  Component: UsersPage.tsx                                       │
│  Purpose: Manage external care providers (Doctors)             │
└─────────────────────────────────────────────────────────────────┘

User Journey: View Users
┌─────────┐      ┌──────────────┐      ┌─────────────────┐
│ Landing │─────>│ Table        │─────>│ See All Doctors │
│  Page   │      │ Display      │      │                 │
└─────────┘      └──────────────┘      └─────────────────┘
                        │
                        └─> API Call: GET /api/users?role=Doctor

Table Structure:
┌──────────────┬────────┬──────────────┬───────────┬────────┬─────────┐
│ Name         │ Role   │ Organization │ Contact   │ Status │ Actions │
├──────────────┼────────┼──────────────┼───────────┼────────┼─────────┤
│ Dr. Sarah    │ Doctor │ Sunrise      │ email     │ Active │ ⋮       │
│ Johnson      │        │ Medical      │ phone     │        │         │
│              │        │ Group        │           │        │         │
├──────────────┼────────┼──────────────┼───────────┼────────┼─────────┤
│ Dr. Michael  │ Doctor │ Heart Care   │ email     │ Active │ ⋮       │
│ Chen         │        │ Specialists  │ phone     │        │         │
└──────────────┴────────┴──────────────┴───────────┴────────┴─────────┘

User Journey: Add User
┌───────────┐   ┌──────────┐   ┌──────────────┐   ┌─────────┐
│ Click Add │──>│ Open     │──>│ Fill Form    │──>│ Submit  │
│ User      │   │ Dialog   │   │ - Name       │   │         │
└───────────┘   └──────────┘   │ - Email      │   └─────────┘
                                │ - Phone      │        │
                                │ - Role       │        │
                                │ - Org        │        │
                                │ - Specialty  │        │
                                │ - Status     │        │
                                └──────────────┘        │
                                                        └─> POST /api/users
```

---

## 5. Messaging System Workflow

```
┌─────────────────────────────────────────────────────────────────┐
│                    MESSAGING SYSTEM                             │
│  Components: MessagingPage.tsx (Admin)                         │
│              NormalUserMessagingPage.tsx (Family)              │
│              ConversationList.tsx, ChatView.tsx                │
└─────────────────────────────────────────────────────────────────┘

Page Layout (Admin View):
┌────────────────────────────────────────────────────────────────┐
│                    MESSAGING PAGE                              │
├──────────────────────┬─────────────────────────────────────────┤
│  CONVERSATION LIST   │          CHAT VIEW                      │
│  (Left 30%)          │          (Right 70%)                    │
│                      │                                         │
│  ┌────────────────┐  │  ┌───────────────────────────────────┐ │
│  │ Resident Name  │  │  │ Resident Name                     │ │
│  │ Participants   │  │  │ Participants: Staff, Nurse, etc. │ │
│  │ Last Message   │  │  └───────────────────────────────────┘ │
│  │ [2] unread     │  │                                         │
│  └────────────────┘  │  ┌───────────────────────────────────┐ │
│                      │  │ Message History                   │ │
│  ┌────────────────┐  │  │                                   │ │
│  │ Resident Name  │  │  │ [Jennifer Lee - Staff]            │ │
│  │ Participants   │  │  │ How is she today?                 │ │
│  │ Last Message   │  │  │ 9:00 AM                           │ │
│  └────────────────┘  │  │                                   │ │
│                      │  │ [You - Staff]                     │ │
│  [+ New Message]     │  │ She's doing great!                │ │
│                      │  │ 9:15 AM                           │ │
│                      │  │                                   │ │
│                      │  └───────────────────────────────────┘ │
│                      │                                         │
│                      │  ┌───────────────────────────────────┐ │
│                      │  │ Type message...          [Send]   │ │
│                      │  └───────────────────────────────────┘ │
└──────────────────────┴─────────────────────────────────────────┘

User Journey: View Conversations (Admin)
┌─────────┐   ┌────────────┐   ┌──────────────┐   ┌─────────────┐
│ Land on │──>│ Load List  │──>│ Group by     │──>│ Display     │
│ Page    │   │            │   │ Resident     │   │ List        │
└─────────┘   └────────────┘   └──────────────┘   └─────────────┘
                    │
                    └─> GET /api/conversations?userId=current

User Journey: Select & View Conversation
┌───────────┐   ┌────────────┐   ┌──────────────┐   ┌─────────────┐
│ Click     │──>│ Load Full  │──>│ Display      │──>│ Mark as     │
│ Convers.  │   │ Messages   │   │ Chat         │   │ Read        │
└───────────┘   └────────────┘   └──────────────┘   └─────────────┘
                      │                                     │
                      │                                     │
                      └─> GET /api/conversations/:id        │
                                                            │
                                                            └─> PATCH /api/conversations/:id/read

User Journey: Send Message
┌───────────┐   ┌────────────┐   ┌──────────────┐   ┌─────────────┐
│ Type      │──>│ Click Send │──>│ Optimistic   │──>│ API Call    │
│ Message   │   │            │   │ Update UI    │   │             │
└───────────┘   └────────────┘   └──────────────┘   └─────────────┘
                                                            │
                                                            └─> POST /api/conversations/:id/messages

Message Flow:
┌──────────┐                    ┌──────────┐
│  User    │───── Send ────────>│  Server  │
│  Types   │                    │          │
│ Message  │                    │  Saves   │
└──────────┘                    │  to DB   │
     │                          └──────────┘
     │                               │
     ├─ Immediately shows in UI      │
     │  (Optimistic Update)          │
     │                               │
     └─────────────────<─────────────┘
           Confirmation/Error

User Journey: Start New Conversation
┌───────────┐   ┌──────────┐   ┌──────────────┐   ┌─────────────┐
│ Click New │──>│ Open     │──>│ Select       │──>│ Send First  │
│ Message   │   │ Modal    │   │ - Resident   │   │ Message     │
└───────────┘   └──────────┘   │ - Parts.     │   └─────────────┘
                                └──────────────┘          │
                                                          │
                                    ┌─────────────────────┘
                                    │
                                    └─> POST /api/conversations
                                        Body: {
                                          residentId,
                                          participantIds,
                                          initialMessage
                                        }

Family View Differences:
┌────────────────────────────────────────────────────────────────┐
│  FAMILY MESSAGING PAGE                                         │
├────────────────────────────────────────────────────────────────┤
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ 🎯 FEATURED PARTNER BANNER                              │  │
│  │ Caring Hands Home Health                                │  │
│  │ Trusted partner for in-home care services               │  │
│  │ Featured Partner                                        │  │
│  │                                      [Learn More]       │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                │
│  Conversations (Filtered to family's loved ones only)          │
│  ┌────────────────┐                                            │
│  │ About Mom      │  [Same chat view as admin]                │
│  │ Staff Messages │                                            │
│  └────────────────┘                                            │
└────────────────────────────────────────────────────────────────┘
```

---

## 6. Data Flow Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     FRONTEND ARCHITECTURE                       │
└─────────────────────────────────────────────────────────────────┘

Component Layer
┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐
│ Residents   │  │   Staff     │  │  Vendors    │  │  Messaging  │
│   Page      │  │   Page      │  │   Page      │  │    Page     │
└──────┬──────┘  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘
       │                │                │                │
       └────────────────┴────────────────┴────────────────┘
                            │
                            ▼
                    ┌───────────────┐
                    │  Custom Hooks │
                    │  Layer        │
                    └───────┬───────┘
                            │
       ┌────────────────────┼────────────────────┐
       │                    │                    │
       ▼                    ▼                    ▼
┌─────────────┐  ┌─────────────┐  ┌─────────────┐
│useResidents │  │  useStaff   │  │useConversations│
└──────┬──────┘  └──────┬──────┘  └──────┬──────┘
       │                │                │
       └────────────────┴────────────────┘
                        │
                        ▼
                ┌───────────────┐
                │ Service Layer │
                └───────┬───────┘
                        │
       ┌────────────────┼────────────────┐
       │                │                │
       ▼                ▼                ▼
┌─────────────┐  ┌─────────────┐  ┌─────────────┐
│ residents   │  │   staff     │  │  messaging  │
│  Service    │  │  Service    │  │   Service   │
└──────┬──────┘  └──────┬──────┘  └──────┬──────┘
       │                │                │
       └────────────────┴────────────────┘
                        │
                        ▼
                ┌───────────────┐
                │  Base API     │
                │  Service      │
                └───────┬───────┘
                        │
                        ▼
                ┌───────────────┐
                │  fetch API    │
                └───────┬───────┘
                        │
                        ▼
              ┌─────────────────┐
              │  Backend API    │
              │  Endpoints      │
              └─────────────────┘
```

---

## 7. State Management Flow

```
User Action Flow:
┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐
│  User    │───>│Component │───>│  Hook    │───>│ Service  │
│  Action  │    │  Event   │    │ Function │    │  Method  │
└──────────┘    └──────────┘    └──────────┘    └────┬─────┘
                                                      │
                                                      ▼
                                               ┌──────────┐
                                               │   API    │
                                               │  Request │
                                               └────┬─────┘
                                                    │
                     ┌──────────────────────────────┘
                     │
                     ▼
           ┌─────────────────┐
           │  Loading State  │
           │  (loading=true) │
           └────────┬────────┘
                    │
      ┌─────────────┴─────────────┐
      │                           │
      ▼                           ▼
┌──────────┐              ┌──────────┐
│ Success  │              │  Error   │
│ Response │              │ Response │
└────┬─────┘              └────┬─────┘
     │                         │
     ▼                         ▼
┌──────────┐              ┌──────────┐
│ Update   │              │ Set      │
│ State    │              │ Error    │
│ Array    │              │ Message  │
└────┬─────┘              └────┬─────┘
     │                         │
     ▼                         ▼
┌──────────┐              ┌──────────┐
│  UI      │              │  Show    │
│ Re-render│              │  Toast   │
└──────────┘              └──────────┘

Optimistic Update Flow (for Create/Update/Delete):
┌──────────┐    ┌──────────┐    ┌──────────┐
│  User    │───>│Immediately│───>│   API    │
│  Action  │    │Update UI  │    │  Request │
└──────────┘    └──────────┘    └────┬─────┘
                                     │
                      ┌──────────────┴──────────────┐
                      │                             │
                      ▼                             ▼
                ┌──────────┐                  ┌──────────┐
                │ Success  │                  │  Error   │
                │ Keep UI  │                  │ Rollback │
                │ Changes  │                  │   UI     │
                └──────────┘                  └──────────┘
```

---

## 8. Error Handling Workflow

```
Error Scenarios:
┌─────────────────────────────────────────────────────────────────┐
│                     ERROR HANDLING                              │
└─────────────────────────────────────────────────────────────────┘

Network Error:
┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐
│   API    │───>│  Catch   │───>│   Set    │───>│  Show    │
│  Fails   │    │  Error   │    │  Error   │    │  Toast   │
│          │    │          │    │  State   │    │ Message  │
└──────────┘    └──────────┘    └──────────┘    └──────────┘
                                                      │
                                                      ▼
                                              "Failed to load
                                               residents. Please
                                               try again."

Validation Error (400):
┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐
│  Submit  │───>│  API     │───>│  Parse   │───>│  Show    │
│   Form   │    │ Returns  │    │  Error   │    │  Field   │
│          │    │   400    │    │ Details  │    │  Errors  │
└──────────┘    └──────────┘    └──────────┘    └──────────┘
                                                      │
                                                      ▼
                                              "Email is required"
                                              "Phone format invalid"

Authentication Error (401):
┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐
│   API    │───>│ Detect   │───>│  Clear   │───>│ Redirect │
│ Returns  │    │   401    │    │  Token   │    │   to     │
│   401    │    │          │    │          │    │  Login   │
└──────────┘    └──────────┘    └──────────┘    └──────────┘

Server Error (500):
┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐
│   API    │───>│  Catch   │───>│   Log    │───>│  Show    │
│ Returns  │    │  Error   │    │  Error   │    │ Generic  │
│   500    │    │          │    │          │    │ Message  │
└──────────┘    └──────────┘    └──────────┘    └──────────┘
                                                      │
                                                      ▼
                                              "Something went wrong.
                                               Please try again later."
```

---

## 9. Complete User Journey Example

**Scenario: Admin adds a new resident and sends first message**

```
Step 1: Add Resident
┌──────────────────────────────────────────────────────────────┐
│ User navigates to Residents page                            │
└────────────┬─────────────────────────────────────────────────┘
             │
             ▼
┌──────────────────────────────────────────────────────────────┐
│ Clicks "Add Resident" button                                │
└────────────┬─────────────────────────────────────────────────┘
             │
             ▼
┌──────────────────────────────────────────────────────────────┐
│ Modal opens with form                                       │
│ - Personal Info (name, DOB, room)                          │
│ - Medical Info (conditions, medications)                   │
│ - Emergency Contacts                                        │
│ - Insurance                                                 │
└────────────┬─────────────────────────────────────────────────┘
             │
             ▼
┌──────────────────────────────────────────────────────────────┐
│ Fills out form fields                                       │
│ - First Name: "John"                                        │
│ - Last Name: "Smith"                                        │
│ - Room: "102B"                                              │
│ - Care Level: "Assisted"                                    │
│ - etc.                                                      │
└────────────┬─────────────────────────────────────────────────┘
             │
             ▼
┌──────────────────────────────────────────────────────────────┐
│ Clicks "Add Resident"                                       │
└────────────┬─────────────────────────────────────────────────┘
             │
             ▼
┌──────────────────────────────────────────────────────────────┐
│ API Call: POST /api/residents                               │
│ Response: { data: { id: "123", firstName: "John", ... }}   │
└────────────┬─────────────────────────────────────────────────┘
             │
             ▼
┌──────────────────────────────────────────────────────────────┐
│ Success toast: "Resident added successfully"               │
│ Modal closes                                                │
│ New resident appears in grid                                │
└────────────┬─────────────────────────────────────────────────┘
             │
             ▼
Step 2: Start Conversation
┌──────────────────────────────────────────────────────────────┐
│ User navigates to Messaging page                            │
└────────────┬─────────────────────────────────────────────────┘
             │
             ▼
┌──────────────────────────────────────────────────────────────┐
│ Clicks "New Conversation"                                   │
└────────────┬─────────────────────────────────────────────────┘
             │
             ▼
┌──────────────────────────────────────────────────────────────┐
│ Modal opens with form                                       │
│ - Select Resident dropdown                                 │
│ - Select Participants (multi-select)                       │
│ - Message input                                             │
└────────────┬─────────────────────────────────────────────────┘
             │
             ▼
┌──────────────────────────────────────────────────────────────┐
│ Selects "John Smith" as resident                            │
│ Selects "Dr. Johnson" and "Nurse Sarah" as participants    │
│ Types: "Welcome John! Let's coordinate his care."          │
└────────────┬─────────────────────────────────────────────────┘
             │
             ▼
┌──────────────────────────────────────────────────────────────┐
│ Clicks "Start Conversation"                                 │
└────────────┬─────────────────────────────────────────────────┘
             │
             ▼
┌──────────────────────────────────────────────────────────────┐
│ API Call: POST /api/conversations                           │
│ Body: {                                                     │
│   residentId: "123",                                        │
│   participantIds: ["doc1", "nurse1"],                      │
│   initialMessage: "Welcome John! ..."                      │
│ }                                                           │
└────────────┬─────────────────────────────────────────────────┘
             │
             ▼
┌──────────────────────────────────────────────────────────────┐
│ Modal closes                                                │
│ New conversation appears in list                            │
│ Chat view opens with first message                          │
└──────────────────────────────────────────────────────────────┘
```

---

## 10. Performance Optimization Points

```
Optimization Strategy:
┌─────────────────────────────────────────────────────────────────┐
│                    PERFORMANCE OPTIMIZATIONS                    │
└─────────────────────────────────────────────────────────────────┘

1. Debounced Search
   ┌─────────┐  wait 300ms  ┌─────────┐
   │ Typing  │────────────>│ API     │
   │ "John"  │              │ Call    │
   └─────────┘              └─────────┘
   No API calls while typing, only after user stops

2. Pagination
   ┌─────────┐              ┌─────────┐
   │ Load    │────────────>│ Only    │
   │ Page 1  │              │ 12 rows │
   └─────────┘              └─────────┘
   Don't load all residents, load page by page

3. Optimistic Updates
   ┌─────────┐              ┌─────────┐
   │ Update  │────────────>│ Show in │
   │ UI      │  instantly   │ UI      │
   └─────────┘              └─────────┘
   Then confirm with API in background

4. Caching (Future with React Query)
   ┌─────────┐              ┌─────────┐
   │ First   │────────────>│ Cache   │
   │ Load    │              │ Result  │
   └─────────┘              └────┬────┘
                                 │
                                 ▼
                            ┌─────────┐
                            │ Return  │
                            │ Cached  │
                            │ on Next │
                            └─────────┘

5. Lazy Loading Images
   ┌─────────┐              ┌─────────┐
   │ Resident│────────────>│ Load    │
   │ Enters  │              │ Photo   │
   │ View    │              │ Only    │
   └─────────┘              └─────────┘
   Only load images when they're visible
```

---

This workflow documentation provides a complete visual guide for understanding all user journeys and data flows in the Valencia Assisted Living Dashboard.
