
  # Healthcare Dashboard UI Design

  This is a code bundle for Healthcare Dashboard UI Design. The original project is available at https://www.figma.com/design/pFoNx6oOeBzctwmm953mUs/Healthcare-Dashboard-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  